var language = "arabic";

// for thesis purposes

var letters = [
  {id:1, text:"خ"},
  {id:2, text:"ح"},
  {id:3, text:"ج"},
  {id:4, text:"ث"},
  {id:5, text:"ت"},
  {id:6, text:"ب"},
  {id:7, text:"ا"},
  {id:8, text:"ص"},
  {id:9, text:"ش"},
  {id:10, text:"س"},
  {id:11, text:"ز"},
  {id:12, text:"ر"},
  {id:13, text:"ذ"},
  {id:14, text:"د"},
  {id:15, text:"ق"},
  {id:16, text:"ف"},
  {id:17, text:"غ"},
  {id:18, text:"ع"},
  {id:19, text:"ظ"},
  {id:20, text:"ط"},
  {id:21, text:"ض"},
  {id:22, text:"ي"},
  {id:23, text:"و"},
  {id:24, text:"ه"},
  {id:25, text:"ن"},
  {id:26, text:"م"},
  {id:27, text:"ل"},
  {id:28, text:"ك"}
  ];